<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ServiceManifold extends Model
{
    //
}
