<?php
    namespace App\Services\Interfaces;

    interface IUserServiceInterface {

        /**
         * @param array $user
         * @return 
         */
        function postUser(array $user);

    }