@extends('layouts.app')

@section('content')
{{-- Abrire section container--}}
<div>
    
    {{-- <svg id="barcode_two"></svg>
    <svg id="barcode"></svg> --}}
</div>

@endsection


@section('script')
{{-- <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/barcodes/JsBarcode.code128.min.js"></script> --}}
{{-- <script src="js/barcode.js"></script> --}}
@endsection
