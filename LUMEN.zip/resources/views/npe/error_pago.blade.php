@extends('layouts.app')

@section('content')

<div class="alert alert-danger text-center" role="alert">
    <h4 class="alert-heading">No pudimos establece comunicación con los servivios de pago, intentalo nuevamente!</h4>
    <p>Si los problemas persisten contacte a soporte tecnico.</p>
    <hr>
</div>

@endsection


@section('script')

@endsection